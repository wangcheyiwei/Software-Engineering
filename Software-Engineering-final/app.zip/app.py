from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your-secret-key'  # 设置用于会话加密的密钥


# 创建数据库连接和表
def create_database():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY, password TEXT, is_admin INTEGER)''')
    conn.commit()
    conn.close()


# 注册用户
def register_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
    conn.commit()
    conn.close()


def register_admin(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO admins (username, password) VALUES (?, ?)", (username, password))
    conn.commit()
    conn.close()


def register_farmer(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO farmers (username, password) VALUES (?, ?)", (username, password))
    conn.commit()
    conn.close()


# 验证登录
def login_user(username, password, user_type):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    if user_type == "0":
        c.execute("SELECT password FROM admins WHERE username=?", (username,))
    elif user_type == "1":
        c.execute("SELECT password FROM farmers WHERE username=?", (username,))
    elif user_type == "2":
        c.execute("SELECT password FROM users WHERE username=?", (username,))
    result = c.fetchone()
    conn.close()
    if result and result[0] == password:
        return 0
    return None


# 设置用户为管理员
def set_user_as_admin(username):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("UPDATE users SET is_admin=1 WHERE username=?", (username,))
    conn.commit()
    conn.close()


# 项目介绍页面
@app.route('/')
def index():
    return render_template('index.html')


# 注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        register_type = request.form['register_type']

        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT username FROM users WHERE username=?", (username,))
        result = c.fetchone()
        conn.close()
        if result:
            return "该用户名已被注册，请选择其他用户名。"

        if register_type == "0":
            register_admin(username, password)
        elif register_type == "1":
            register_farmer(username, password)
        elif register_type == "2":
            register_user(username, password)
        return redirect('/login')
    return render_template('register_haha.html')


# 登录页面
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_type = request.form['user_type']
        res = login_user(username, password, user_type)
        if res is not None:
            session['username'] = username
            session['user_type'] = user_type
            if user_type == "0":
                return redirect('/admin')
            elif user_type == "1":
                return redirect('/famer')
            elif user_type == "2":
                return redirect('/user')
        else:
            return "登录失败，请检查用户名和密码。"
    return render_template('login_haha.html')


# 用户注销
@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('user_type', None)
    return redirect('/')


# 用户页面
@app.route('/user')
def user():
    if 'username' in session and session['user_type'] == "2":
        return render_template('user.html')
    else:
        return redirect('/login')


# ---------------------------------------
# underwater 页面
@app.route('/underwater')
def underwater():
    if 'username' in session:
        return render_template('underwater.html')
    else:
        return redirect('/login')


# datacenter 页面
@app.route('/datacenter')
def datacenter():
    if 'username' in session:
        return render_template('datacenter.html')
    else:
        return redirect('/login')


# intelligentcenter 页面
@app.route('/intelligentcenter')
def intelligentcenter():
    if 'username' in session:
        return render_template('intelligentcenter.html')
    else:
        return redirect('/login')


# ---------------------------------------
# 管理员页面
@app.route('/admin')
def admin():
    if 'username' in session and session['user_type'] == "0":
        return render_template('admin.html')
    else:
        return redirect('/login')


# ---------------------------------------
# ---------------------------------------
# underwater 页面
@app.route('/underwater_plus')
def underwater_plus():
    if 'username' in session:
        return render_template('underwater_plus.html')
    else:
        return redirect('/login')


# datacenter 页面
@app.route('/datacenter_plus')
def datacenter_plus():
    if 'username' in session:
        return render_template('datacenter_plus.html')
    else:
        return redirect('/login')


# intelligentcenter 页面
@app.route('/intelligentcenter_plus')
def intelligentcenter_plus():
    if 'username' in session:
        return render_template('intelligentcenter_plus.html')
    else:
        return redirect('/login')


# ---------------------------------------

# 设置用户为管理员
@app.route('/admin/set_admin/<username>')
def set_admin(username):
    if 'username' in session and session['user_type'] == "0":
        set_user_as_admin(username)
        return f"已将用户 '{username}' 设置为管理员。"
    else:
        return redirect('/login')


# 养殖户页面
@app.route('/famer')
def famer():
    if 'username' in session and session['user_type'] == "1":
        return render_template('famer.html')
    else:
        return redirect('/login')


# ---------------------------------------
# ---------------------------------------
# underwater 页面
@app.route('/underwater_famer')
def underwater_famer():
    if 'username' in session:
        return render_template('underwater_famer.html')
    else:
        return redirect('/login')


# datacenter 页面
@app.route('/datacenter_famer')
def datacenter_famer():
    if 'username' in session:
        return render_template('datacenter_famer.html')
    else:
        return redirect('/login')


# intelligentcenter 页面
@app.route('/intelligentcenter_famer')
def intelligentcenter_famer():
    if 'username' in session:
        return render_template('intelligentcenter_famer.html')
    else:
        return redirect('/login')


if __name__ == '__main__':
    create_database()
    app.run(debug=True)
